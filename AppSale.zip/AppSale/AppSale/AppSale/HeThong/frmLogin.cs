﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;

namespace AppSale
{
    public partial class frmLogin : DevExpress.XtraEditors.XtraForm
    {
        getData data = new getData();
        methods mt = new methods();
        CauHinhSever CauHinh = new CauHinhSever();
        public frmLogin()
        {
            InitializeComponent();
        }
        Methods.method ham = new Methods.method();

        private void groupControl1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            ProcessLogin();
            
            //----------------------------

            //if (CauHinh.Check_Config() == 0)
            //{
            //    ProcessLogin();// Cấu hình phù hợp xử lý đăng nhập
            //}
            //if (CauHinh.Check_Config() == 1)
            //{
            //    MessageBox.Show("Chuỗi cấu hình không tồn tại");// Xử lý cấu hình
            //    ProcessConfig();
            //}
            //if (CauHinh.Check_Config() == 2)
            //{
            //    MessageBox.Show("Chuỗi cấu hình không phù hợp");// Xử lý cấu hình
            //    ProcessConfig();
            //}
            
        }
        public void ProcessLogin()
        {
            if (txtTK.Text == string.Empty || txtMK.Text == string.Empty)
            {
                MessageBox.Show("Mời nhâp đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ham.ClearText(this);

            }
            else if (mt.checkUserAndPassword(txtTK.Text.ToString(), txtMK.Text.ToString()))
            {
                frmMain main = new frmMain();
                main.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Tài khoản hoặc mật khẩu không hợp lệ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ham.ClearText(this);
            }
        }
        public void ProcessConfig()
        {
            HeThong.frmCauHinh frm = new HeThong.frmCauHinh();
            this.Hide();
            frm.ShowDialog();
            this.Show();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;

namespace AppSale
{
    public partial class frmNhanVien : DevExpress.XtraEditors.XtraForm
    {
        Methods.method ham = new Methods.method();
        getData dt = new getData();
        methods mt = new methods();
        BindingSource bs = new BindingSource();

        public frmNhanVien()
        {
            InitializeComponent();
        }

        private void frmNhanVien_Load(object sender, EventArgs e)
        {
            loadNV();

        }
        #region Events
        private void btnAddNV_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            AddNV();
        }
        private void btnDelete_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DeleteNV();


        }
        private void btnEdit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            EditNV();
        }
        private void btnSave_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            SaveNV();
        }
        #endregion

        #region Methods
        private void ResetText()
        {
            txtMa.ResetText();
            txtHoTen.ResetText();
            txtSdt.ResetText();
            txtDiaChi.ResetText();
            txtMa.Focus();
        }
        private void loadNV()
        {
            gridControl1.DataSource = dt.getNhanVien();
        }
        private void EditNV()
        {
            txtMa.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "MaNV").ToString();
            txtHoTen.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "TenNV").ToString();
            txtSdt.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "SDT").ToString();
            txtDiaChi.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "DiaChi").ToString();
        }

        private void DeleteNV()
        {
            if (MessageBox.Show("Bạn có chắc muốn xóa nhân viên", "Thông Báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != System.Windows.Forms.DialogResult.Cancel)
            {
                string id = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "MaNV").ToString();
                mt.DeleteNV(id);
            }

            loadNV();
        }
        
        private void AddNV()
        {           
            ResetText();
            ham.ClearText(this);

            MaTuDongTang();
         }
        private void MaTuDongTang()
        {
            if (gridView1.RowCount + 1 < 10)
                txtMa.Text = "NV0" + (gridView1.RowCount + 1).ToString();
            else
                txtMa.Text = "NV" + (gridView1.RowCount + 1).ToString();

        }

        private void SaveNV()
        {
            if (txtMa.Text == string.Empty || txtHoTen.Text == string.Empty || txtSdt.Text == string.Empty || txtDiaChi.Text == string.Empty)
            {
                MessageBox.Show("Mời nhập đầy đủ thông tin", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                mt.AddNV(txtMa.Text, txtHoTen.Text, txtSdt.Text.ToString(), txtDiaChi.Text);
                loadNV();
            }
        }
        #endregion


        private void gridView1_MouseEnter(object sender, EventArgs e)
        {
            //txtMa.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "maNV").ToString();
            //txtHoTen.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "tenNV").ToString();
            //txtSdt.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "SDT").ToString();
            //txtDiaChi.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "diaChi").ToString();
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (txtHoTen.Text == string.Empty || txtSdt.Text == string.Empty || txtDiaChi.Text == string.Empty)
            {
                MessageBox.Show("Mời nhập đầy đủ thông tin", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                mt.EditNV(txtMa.Text, txtHoTen.Text, txtSdt.Text, txtDiaChi.Text);
                loadNV();
            }
            loadNV();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddNV();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

        }

       





        

        
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;

namespace AppSale.HeThong
{
    public partial class frmCauHinh : DevExpress.XtraEditors.XtraForm
    {
        //CauHinhSever CauHinh = new CauHinhSever();
        
        public frmCauHinh()
        {
            InitializeComponent();
        }

        private void frmCauHinh_Load(object sender, EventArgs e)
        {

        }

        private void cboSever_DropDown(object sender, EventArgs e)
        {
            //DataTable dt = CauHinh.GetServerName();
            //cboServer.Items.Clear();
            //foreach (System.Data.DataRow row in dt.Rows)
            //{
            //    foreach (System.Data.DataColumn col in dt.Columns)
            //    {
            //        cboServer.Items.Add(row[col]);
            //    }
            //}
        }

        private void cboDatabase_DropDown(object sender, EventArgs e)
        {
            //if (CheckedBeforSearchNameDB())
            //{
            //    cboDataBase.Items.Clear();
            //    List<string> _list = CauHinh.GetDatabaseName(cboServer.Text, txtUsername.Text, txtPassword.Text);
            //    if (_list == null)
            //    {
            //        MessageBox.Show("Thông tin cấu hình chưa chính xác");
            //        return;
            //    }
            //    foreach (string item in _list)
            //    {
            //        cboDataBase.Items.Add(item);
            //    }
            //}
        }
        public bool CheckedBeforSearchNameDB()
        {
            if (cboServer.Text == string.Empty)
            {
                MessageBox.Show("");
                cboServer.Focus();
                return false;
            }
            if (txtUsername.Text == string.Empty)
            {
                MessageBox.Show("");
                txtUsername.Focus();
                return false;
            }
            if (txtPassword.Text == string.Empty)
            {
                MessageBox.Show("");
                txtPassword.Focus();
                return false;
            }

            return true;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            //CauHinh.ChangeConnectionString(cboServer.Text, cboDataBase.Text, txtUsername.Text, txtPassword.Text);
            //this.Close();
        }

        private void btnHuyBo_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
            Application.Exit();
        }
    }
}
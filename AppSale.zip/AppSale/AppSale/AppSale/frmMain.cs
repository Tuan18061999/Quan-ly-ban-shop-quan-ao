﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AppSale
{
    public partial class frmMain : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            Skin();
        }

        #region Methods
        #region LoadForm
        private void Skin()
        {
            DevExpress.LookAndFeel.DefaultLookAndFeel themes = new DevExpress.LookAndFeel.DefaultLookAndFeel();

            themes.LookAndFeel.SkinName = "McSkin";
        }
        private Form isActive(Type fType)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f.GetType() == fType)
                {
                    return f;
                }
            }
            return null;
        }
        private void loadNhap()
        {
            Form f = isActive(typeof(TacVu.frmNhapHang));
            if (f == null)
            {
                TacVu.frmNhapHang fNhap = new TacVu.frmNhapHang();
                fNhap.MdiParent = this;
                fNhap.Show();
            }
            else
                f.Activate();
        }
        private void loadNhanVien()
        {
            Form f = isActive(typeof(frmNhanVien));
            if (f == null)
            {
                frmNhanVien fNhanVien = new frmNhanVien();
                fNhanVien.MdiParent = this;
                fNhanVien.Show();
            }
            else
                f.Activate();
        }
        private void loadLogin()
        {
            Form f = isActive(typeof(frmLogin));
            if (f == null)
            {
                frmLogin flogin = new frmLogin();
                flogin.MdiParent = this;
                flogin.Show();
            }
            else
                f.Activate();
        }
        private void loadBanHang()
        {
            Form f = isActive(typeof(TacVu.frmBanHang));
            if (f == null)
            {
                TacVu.frmBanHang fban = new TacVu.frmBanHang();
                fban.MdiParent = this;
                fban.Show();
            }
            else
                f.Activate();
        }

        private void frmThongKe()
        {
            Form f = isActive(typeof(TacVu.frmThongKe));
            if (f == null)
            {
                TacVu.frmThongKe fThongKe = new TacVu.frmThongKe();
                fThongKe.MdiParent = this;
                fThongKe.Show();
            }
            else
                f.Activate();
        }
        private void BaoCaoBanHang()
        {
            Form f = isActive(typeof(TacVu.frmBanHang));
            if (f == null)
            {
                TacVu.frmBanHang fBan = new TacVu.frmBanHang();
                fBan.MdiParent = this;
                fBan.Show();
            }
            else
                f.Activate();
        }
        private void frmHangHoa()
        {
            Form f = isActive(typeof(TacVu.frmHangHoa));
            if (f == null)
            {
                TacVu.frmHangHoa hh = new TacVu.frmHangHoa();
                hh.MdiParent = this;
                hh.Show();
            }
            else
                f.Activate();
        }
        private void NhaCungCap()
        {
            Form f = isActive(typeof(TacVu.frmNhaCungCap));
            if (f == null)
            {
                TacVu.frmNhaCungCap ncc = new TacVu.frmNhaCungCap();
                ncc.MdiParent = this;
                ncc.Show();
            }
            else
                f.Activate();
        }
        private void KhachHang()
        {
            Form f = isActive(typeof(TacVu.frmKhachHang));
            if (f == null)
            {
                TacVu.frmKhachHang kh = new TacVu.frmKhachHang();
                kh.MdiParent = this;
                kh.Show();
            }
            else
                f.Activate();
        }
        #endregion

        #endregion

        #region Events
        private void hoát_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn thoát chương trình ?","Thông báo",MessageBoxButtons.OKCancel,MessageBoxIcon.Question) != System.Windows.Forms.DialogResult.Cancel)
                this.Close();         
        }
        private void btnHangHoa_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmHangHoa();
        }

        private void btnThongKe_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            frmThongKe();
        }

   
        private void btnLogin_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            loadLogin();
        }

        private void btnNhanVien_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            loadNhanVien();
        }

        private void btnNhapHang_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            loadNhap();
        }
        private void btnBanHang_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            loadBanHang();
        }
        private void btnReportBan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            BaoCaoBanHang();
        }
        private void btnNCC_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            NhaCungCap();
        }

        private void btnKhachHang_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            KhachHang();
        }
        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            loadLogin();
        }
        #endregion

      

        

        


        

       

       

      

     

       
    }
}

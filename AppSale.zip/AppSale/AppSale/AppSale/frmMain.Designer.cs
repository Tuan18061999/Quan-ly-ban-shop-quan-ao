﻿namespace AppSale
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonControl2 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.btnLogin = new DevExpress.XtraBars.BarButtonItem();
            this.btnResetPass = new DevExpress.XtraBars.BarButtonItem();
            this.btnLogout = new DevExpress.XtraBars.BarButtonItem();
            this.btnPhanQuyen = new DevExpress.XtraBars.BarButtonItem();
            this.btnBackUp = new DevExpress.XtraBars.BarButtonItem();
            this.skinPaletteRibbonGalleryBarItem1 = new DevExpress.XtraBars.SkinPaletteRibbonGalleryBarItem();
            this.skinRibbonGalleryBarItem1 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.btnNhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.btnQuyen = new DevExpress.XtraBars.BarButtonItem();
            this.btnRestore = new DevExpress.XtraBars.BarButtonItem();
            this.btnNhapHang = new DevExpress.XtraBars.BarButtonItem();
            this.btnBanHang = new DevExpress.XtraBars.BarButtonItem();
            this.btnThongKe = new DevExpress.XtraBars.BarButtonItem();
            this.btnDoanhThu = new DevExpress.XtraBars.BarButtonItem();
            this.btnReportNhap = new DevExpress.XtraBars.BarButtonItem();
            this.btnReportBan = new DevExpress.XtraBars.BarButtonItem();
            this.btnHangHoa = new DevExpress.XtraBars.BarButtonItem();
            this.btnKhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.btnNCC = new DevExpress.XtraBars.BarButtonItem();
            this.btnHang = new DevExpress.XtraBars.BarButtonItem();
            this.thoát = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup7 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.tabTacVu = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.xtraTabbedMdiManager1 = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager(this.components);
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.btnChangePass = new DevExpress.XtraEditors.SimpleButton();
            this.btnDangXuat = new DevExpress.XtraEditors.SimpleButton();
            this.textEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Hệ Thống";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Hệ Thống";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Hệ Thống";
            // 
            // ribbonControl2
            // 
            this.ribbonControl2.ExpandCollapseItem.Id = 0;
            this.ribbonControl2.Images = this.imageCollection1;
            this.ribbonControl2.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl2.ExpandCollapseItem,
            this.ribbonControl2.SearchEditItem,
            this.btnLogin,
            this.btnResetPass,
            this.btnLogout,
            this.btnPhanQuyen,
            this.btnBackUp,
            this.skinPaletteRibbonGalleryBarItem1,
            this.skinRibbonGalleryBarItem1,
            this.btnNhanVien,
            this.btnQuyen,
            this.btnRestore,
            this.btnNhapHang,
            this.btnBanHang,
            this.btnThongKe,
            this.btnDoanhThu,
            this.btnReportNhap,
            this.btnReportBan,
            this.btnHangHoa,
            this.btnKhachHang,
            this.btnNCC,
            this.btnHang,
            this.thoát});
            this.ribbonControl2.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl2.Margin = new System.Windows.Forms.Padding(4);
            this.ribbonControl2.MaxItemId = 23;
            this.ribbonControl2.Name = "ribbonControl2";
            this.ribbonControl2.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage5,
            this.tabTacVu});
            this.ribbonControl2.Size = new System.Drawing.Size(1252, 231);
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "add_folder_48px.png");
            this.imageCollection1.Images.SetKeyName(1, "add_user_male_96px.png");
            this.imageCollection1.Images.SetKeyName(2, "businessman_96px.png");
            this.imageCollection1.Images.SetKeyName(3, "buying_96px.png");
            this.imageCollection1.Images.SetKeyName(4, "cancel_48px.png");
            this.imageCollection1.Images.SetKeyName(5, "cancel_96px.png");
            this.imageCollection1.Images.SetKeyName(6, "checked_48px.png");
            this.imageCollection1.Images.SetKeyName(7, "checkmark_48px.png");
            this.imageCollection1.Images.SetKeyName(8, "close_window_96px.png");
            this.imageCollection1.Images.SetKeyName(9, "customer_48px.png");
            this.imageCollection1.Images.SetKeyName(10, "customer_96px.png");
            this.imageCollection1.Images.SetKeyName(11, "delete_48px.png");
            this.imageCollection1.Images.SetKeyName(12, "discount_96px.png");
            this.imageCollection1.Images.SetKeyName(13, "edit_48px.png");
            this.imageCollection1.Images.SetKeyName(14, "forgot_password_96px.png");
            this.imageCollection1.Images.SetKeyName(15, "hide_48px.png");
            this.imageCollection1.Images.SetKeyName(16, "hide_96px.png");
            this.imageCollection1.Images.SetKeyName(17, "information_96px.png");
            this.imageCollection1.Images.SetKeyName(18, "key_2_48px.png");
            this.imageCollection1.Images.SetKeyName(19, "key_96px.png");
            this.imageCollection1.Images.SetKeyName(20, "lock_48px.png");
            this.imageCollection1.Images.SetKeyName(21, "low_price_96px.png");
            this.imageCollection1.Images.SetKeyName(22, "maintenance_48px.png");
            this.imageCollection1.Images.SetKeyName(23, "maintenance_96px.png");
            this.imageCollection1.Images.SetKeyName(24, "male_user_96px.png");
            this.imageCollection1.Images.SetKeyName(25, "manager_96px.png");
            this.imageCollection1.Images.SetKeyName(26, "ok_48px.png");
            this.imageCollection1.Images.SetKeyName(27, "ok_96px.png");
            this.imageCollection1.Images.SetKeyName(28, "opened_folder_48px.png");
            this.imageCollection1.Images.SetKeyName(29, "person_96px.png");
            this.imageCollection1.Images.SetKeyName(30, "plus_48px.png");
            this.imageCollection1.Images.SetKeyName(31, "plus_96px.png");
            this.imageCollection1.Images.SetKeyName(32, "plus_math_96px.png");
            this.imageCollection1.Images.SetKeyName(33, "sales_performance_96px.png");
            this.imageCollection1.Images.SetKeyName(34, "search_96px.png");
            this.imageCollection1.Images.SetKeyName(35, "secure_48px.png");
            this.imageCollection1.Images.SetKeyName(36, "sell_stock_96px.png");
            this.imageCollection1.Images.SetKeyName(37, "services_48px.png");
            this.imageCollection1.Images.SetKeyName(38, "settings_48px.png");
            this.imageCollection1.Images.SetKeyName(39, "shopping_cart_96px.png");
            this.imageCollection1.Images.SetKeyName(40, "shutdown_48px.png");
            this.imageCollection1.Images.SetKeyName(41, "shutdown_96px.png");
            this.imageCollection1.Images.SetKeyName(42, "sign_out_48px.png");
            this.imageCollection1.Images.SetKeyName(43, "sign_out_96px.png");
            this.imageCollection1.Images.SetKeyName(44, "support_48px.png");
            this.imageCollection1.Images.SetKeyName(45, "support_96px.png");
            this.imageCollection1.Images.SetKeyName(46, "synchronize_48px.png");
            this.imageCollection1.Images.SetKeyName(47, "total_sales_96px.png");
            this.imageCollection1.Images.SetKeyName(48, "trash_can_48px.png");
            this.imageCollection1.Images.SetKeyName(49, "t-shirt_96px.png");
            this.imageCollection1.Images.SetKeyName(50, "undo_48px.png");
            this.imageCollection1.Images.SetKeyName(51, "user_48px.png");
            this.imageCollection1.Images.SetKeyName(52, "workspace_96px.png");
            this.imageCollection1.Images.SetKeyName(53, "icons8_downward_arrow_16.png");
            this.imageCollection1.Images.SetKeyName(54, "icons8_outgoing_data_32.png");
            this.imageCollection1.Images.SetKeyName(55, "icons8_combo_chartcolor_32.png");
            this.imageCollection1.Images.SetKeyName(56, "icons8_graph_report_32.png");
            this.imageCollection1.Images.SetKeyName(57, "total_sales_96px.png");
            this.imageCollection1.Images.SetKeyName(58, "icons8_google_presentation_64.png");
            this.imageCollection1.Images.SetKeyName(59, "icons8_data_backup_64.png");
            this.imageCollection1.Images.SetKeyName(60, "icons8_data_recovery_64.png");
            // 
            // btnLogin
            // 
            this.btnLogin.Caption = "Đăng Nhập";
            this.btnLogin.Id = 1;
            this.btnLogin.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLogin.ImageOptions.Image")));
            this.btnLogin.ImageOptions.ImageIndex = 10;
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnLogin.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnLogin_ItemClick);
            // 
            // btnResetPass
            // 
            this.btnResetPass.Caption = "Đổi Mật Khẩu";
            this.btnResetPass.Id = 2;
            this.btnResetPass.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnResetPass.ImageOptions.Image")));
            this.btnResetPass.ImageOptions.ImageIndex = 20;
            this.btnResetPass.Name = "btnResetPass";
            // 
            // btnLogout
            // 
            this.btnLogout.Caption = "Đăng Xuất";
            this.btnLogout.Id = 3;
            this.btnLogout.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLogout.ImageOptions.Image")));
            this.btnLogout.ImageOptions.ImageIndex = 43;
            this.btnLogout.Name = "btnLogout";
            // 
            // btnPhanQuyen
            // 
            this.btnPhanQuyen.Caption = "Phân Quyền Người Dùng";
            this.btnPhanQuyen.Id = 4;
            this.btnPhanQuyen.ImageOptions.ImageIndex = 2;
            this.btnPhanQuyen.Name = "btnPhanQuyen";
            this.btnPhanQuyen.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnBackUp
            // 
            this.btnBackUp.Caption = "Sao Lưu Dữ Liệu";
            this.btnBackUp.Id = 5;
            this.btnBackUp.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnBackUp.ImageOptions.Image")));
            this.btnBackUp.ImageOptions.ImageIndex = 59;
            this.btnBackUp.Name = "btnBackUp";
            this.btnBackUp.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // skinPaletteRibbonGalleryBarItem1
            // 
            this.skinPaletteRibbonGalleryBarItem1.Caption = "skinPaletteRibbonGalleryBarItem1";
            this.skinPaletteRibbonGalleryBarItem1.Id = 6;
            this.skinPaletteRibbonGalleryBarItem1.Name = "skinPaletteRibbonGalleryBarItem1";
            // 
            // skinRibbonGalleryBarItem1
            // 
            this.skinRibbonGalleryBarItem1.Caption = "skinRibbonGalleryBarItem1";
            this.skinRibbonGalleryBarItem1.Id = 7;
            this.skinRibbonGalleryBarItem1.Name = "skinRibbonGalleryBarItem1";
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.Caption = "Quản Lý Nhân Viên";
            this.btnNhanVien.Id = 9;
            this.btnNhanVien.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNhanVien.ImageOptions.Image")));
            this.btnNhanVien.ImageOptions.ImageIndex = 29;
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhanVien_ItemClick);
            // 
            // btnQuyen
            // 
            this.btnQuyen.Caption = "Phân Quyền Hệ Thống";
            this.btnQuyen.Id = 10;
            this.btnQuyen.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnQuyen.ImageOptions.Image")));
            this.btnQuyen.ImageOptions.ImageIndex = 2;
            this.btnQuyen.Name = "btnQuyen";
            this.btnQuyen.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnRestore
            // 
            this.btnRestore.Caption = "Phục Hồi Dữ Liệu";
            this.btnRestore.Id = 11;
            this.btnRestore.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnRestore.ImageOptions.Image")));
            this.btnRestore.ImageOptions.ImageIndex = 60;
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnNhapHang
            // 
            this.btnNhapHang.Caption = "Nhập Hàng";
            this.btnNhapHang.Id = 12;
            this.btnNhapHang.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNhapHang.ImageOptions.Image")));
            this.btnNhapHang.ImageOptions.ImageIndex = 53;
            this.btnNhapHang.Name = "btnNhapHang";
            this.btnNhapHang.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnNhapHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNhapHang_ItemClick);
            // 
            // btnBanHang
            // 
            this.btnBanHang.Caption = "Bán Hàng";
            this.btnBanHang.Id = 13;
            this.btnBanHang.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnBanHang.ImageOptions.Image")));
            this.btnBanHang.ImageOptions.ImageIndex = 54;
            this.btnBanHang.Name = "btnBanHang";
            this.btnBanHang.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnBanHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBanHang_ItemClick);
            // 
            // btnThongKe
            // 
            this.btnThongKe.Caption = "Thống Kê";
            this.btnThongKe.Id = 14;
            this.btnThongKe.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnThongKe.ImageOptions.Image")));
            this.btnThongKe.ImageOptions.ImageIndex = 57;
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnThongKe.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnThongKe_ItemClick);
            // 
            // btnDoanhThu
            // 
            this.btnDoanhThu.Caption = "Báo Cáo Doanh Thu";
            this.btnDoanhThu.Id = 15;
            this.btnDoanhThu.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnDoanhThu.ImageOptions.Image")));
            this.btnDoanhThu.ImageOptions.ImageIndex = 58;
            this.btnDoanhThu.Name = "btnDoanhThu";
            this.btnDoanhThu.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnReportNhap
            // 
            this.btnReportNhap.Caption = "Báo Cáo - Nhập";
            this.btnReportNhap.Id = 16;
            this.btnReportNhap.Name = "btnReportNhap";
            this.btnReportNhap.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnReportBan
            // 
            this.btnReportBan.Caption = "Báo Cáo - Bán";
            this.btnReportBan.Id = 17;
            this.btnReportBan.Name = "btnReportBan";
            this.btnReportBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnReportBan_ItemClick);
            // 
            // btnHangHoa
            // 
            this.btnHangHoa.Caption = "Hàng Hóa";
            this.btnHangHoa.Id = 18;
            this.btnHangHoa.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnHangHoa.ImageOptions.Image")));
            this.btnHangHoa.Name = "btnHangHoa";
            this.btnHangHoa.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnHangHoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHangHoa_ItemClick);
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.Caption = "Khách hàng";
            this.btnKhachHang.Id = 19;
            this.btnKhachHang.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.ImageOptions.Image")));
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnKhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnKhachHang_ItemClick);
            // 
            // btnNCC
            // 
            this.btnNCC.Caption = "Nhà Cung Cấp";
            this.btnNCC.Id = 20;
            this.btnNCC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNCC.ImageOptions.Image")));
            this.btnNCC.Name = "btnNCC";
            this.btnNCC.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnNCC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnNCC_ItemClick);
            // 
            // btnHang
            // 
            this.btnHang.Caption = "Hàng Hóa";
            this.btnHang.Id = 21;
            this.btnHang.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnHang.ImageOptions.Image")));
            this.btnHang.Name = "btnHang";
            this.btnHang.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.btnHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnHangHoa_ItemClick);
            // 
            // thoát
            // 
            this.thoát.Caption = "&Thoát hệ thống";
            this.thoát.Id = 22;
            this.thoát.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("thoát.ImageOptions.Image")));
            this.thoát.Name = "thoát";
            this.thoát.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            this.thoát.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.hoát_ItemClick);
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup3,
            this.ribbonPageGroup4,
            this.ribbonPageGroup7});
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "Hệ Thống";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.btnLogin);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnResetPass);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnLogout);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnNhanVien);
            this.ribbonPageGroup2.ItemLinks.Add(this.btnQuyen);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Hệ Thống";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.btnBackUp);
            this.ribbonPageGroup3.ItemLinks.Add(this.btnRestore);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Dữ Liệu";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.skinRibbonGalleryBarItem1);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Giao Diện";
            // 
            // ribbonPageGroup7
            // 
            this.ribbonPageGroup7.ItemLinks.Add(this.thoát);
            this.ribbonPageGroup7.Name = "ribbonPageGroup7";
            this.ribbonPageGroup7.Text = "Thoát ";
            // 
            // tabTacVu
            // 
            this.tabTacVu.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup5,
            this.ribbonPageGroup6,
            this.ribbonPageGroup1});
            this.tabTacVu.Name = "tabTacVu";
            this.tabTacVu.Text = "Tác Vụ";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.btnNhapHang);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnBanHang);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnHang);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Quản lý hàng";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.btnThongKe);
            this.ribbonPageGroup6.ItemLinks.Add(this.btnDoanhThu);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "Báo Cáo - Thống Kê";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.btnKhachHang);
            this.ribbonPageGroup1.ItemLinks.Add(this.btnNCC);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Đối tác";
            // 
            // xtraTabbedMdiManager1
            // 
            this.xtraTabbedMdiManager1.MdiParent = this;
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.groupControl1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelControl1.Location = new System.Drawing.Point(0, 231);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(252, 497);
            this.panelControl1.TabIndex = 2;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.btnChangePass);
            this.groupControl1.Controls.Add(this.btnDangXuat);
            this.groupControl1.Controls.Add(this.textEdit2);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.textEdit1);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl1.Location = new System.Drawing.Point(2, 2);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(248, 327);
            this.groupControl1.TabIndex = 3;
            this.groupControl1.Text = "Thông tin tài khoản";
            // 
            // btnChangePass
            // 
            this.btnChangePass.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnChangePass.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnChangePass.ImageOptions.Image")));
            this.btnChangePass.Location = new System.Drawing.Point(2, 211);
            this.btnChangePass.Name = "btnChangePass";
            this.btnChangePass.Size = new System.Drawing.Size(244, 57);
            this.btnChangePass.TabIndex = 7;
            this.btnChangePass.Text = "Đổi mật khẩu";
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnDangXuat.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnDangXuat.ImageOptions.Image")));
            this.btnDangXuat.Location = new System.Drawing.Point(2, 268);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(244, 57);
            this.btnDangXuat.TabIndex = 3;
            this.btnDangXuat.Text = "Đăng xuất";
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // textEdit2
            // 
            this.textEdit2.Enabled = false;
            this.textEdit2.Location = new System.Drawing.Point(89, 118);
            this.textEdit2.MenuManager = this.ribbonControl2;
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Size = new System.Drawing.Size(150, 26);
            this.textEdit2.TabIndex = 6;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(8, 121);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(58, 19);
            this.labelControl2.TabIndex = 5;
            this.labelControl2.Text = "Chức vụ";
            // 
            // textEdit1
            // 
            this.textEdit1.Enabled = false;
            this.textEdit1.Location = new System.Drawing.Point(90, 66);
            this.textEdit1.MenuManager = this.ribbonControl2;
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Size = new System.Drawing.Size(150, 26);
            this.textEdit1.TabIndex = 4;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(10, 69);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(70, 19);
            this.labelControl1.TabIndex = 3;
            this.labelControl1.Text = "Tài khoản";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 728);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.ribbonControl2);
            this.IconOptions.Image = ((System.Drawing.Image)(resources.GetObject("frmMain.IconOptions.Image")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Ribbon = this.ribbonControl2;
            this.Text = "Trang Chủ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl2;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.BarButtonItem btnLogin;
        private DevExpress.XtraBars.BarButtonItem btnResetPass;
        private DevExpress.XtraBars.BarButtonItem btnLogout;
        private DevExpress.XtraBars.BarButtonItem btnPhanQuyen;
        private DevExpress.XtraBars.BarButtonItem btnBackUp;
        private DevExpress.XtraBars.SkinPaletteRibbonGalleryBarItem skinPaletteRibbonGalleryBarItem1;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem1;
        private DevExpress.XtraBars.BarButtonItem btnNhanVien;
        private DevExpress.XtraBars.BarButtonItem btnQuyen;
        private DevExpress.XtraBars.BarButtonItem btnRestore;
        private DevExpress.XtraBars.BarButtonItem btnNhapHang;
        private DevExpress.XtraBars.BarButtonItem btnBanHang;
        private DevExpress.XtraBars.BarButtonItem btnThongKe;
        private DevExpress.XtraBars.BarButtonItem btnDoanhThu;
        private DevExpress.XtraBars.BarButtonItem btnReportNhap;
        private DevExpress.XtraBars.BarButtonItem btnReportBan;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.Ribbon.RibbonPage tabTacVu;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager xtraTabbedMdiManager1;
        private DevExpress.XtraBars.BarButtonItem btnHangHoa;
        private DevExpress.XtraBars.BarButtonItem btnKhachHang;
        private DevExpress.XtraBars.BarButtonItem btnNCC;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnDangXuat;
        private DevExpress.XtraEditors.TextEdit textEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraBars.BarButtonItem btnHang;
        private DevExpress.XtraEditors.SimpleButton btnChangePass;
        private DevExpress.XtraBars.BarButtonItem thoát;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup7;

    }
}


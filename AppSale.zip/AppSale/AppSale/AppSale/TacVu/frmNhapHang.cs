﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;


namespace AppSale.TacVu
{
    public partial class frmNhapHang : DevExpress.XtraEditors.XtraForm
    {
        getData data = new getData();
        methods mt = new methods();
        string maPN;
        public frmNhapHang()
        {
            InitializeComponent();
        }
        private void frmNhapHang_Load(object sender, EventArgs e)
        {
            loadDgvPhieuNhap();
        }

        #region Methods dung chung
        Methods.method ham = new Methods.method();
        

        #endregion
        #region Events
        private void btnThem_Click(object sender, EventArgs e)
        {
            ham.ClearText(this);
        }
        private void gridView1_CustomRowCellEditForEditing(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            txtMaPhieuNhap.Text = gridView1.GetRowCellValue(e.RowHandle, "MaPN").ToString().Trim();
            txtNgayNhap.Text = gridView1.GetRowCellValue(e.RowHandle, "NgayNhap").ToString().Trim(); txtNgayNhap.Text = gridView1.GetRowCellValue(e.RowHandle, "NgayNhap").ToString().Trim();
            cboNhanVien.Properties.NullText = gridView1.GetRowCellValue(e.RowHandle, "TenNV").ToString().Trim();
            cboNhaCungCap.Properties.NullText = gridView1.GetRowCellValue(e.RowHandle, "TenNCC").ToString().Trim();
            //txtThanhTien.Text = gridView1.GetRowCellValue(e.RowHandle, "TongTienNhap").ToString().Trim();
            dgvChiTietPhieuNhap.DataSource = data.getChiTietPhieuNhapTheoMa(txtMaPhieuNhap.Text.ToString());
        }
        
        #endregion
        #region Data
        
        public void loadDgvPhieuNhap()
        {
            dgvPhieuNhap.DataSource = data.getPhieuNhap();
            
        }
        #endregion

        private void gridView2_CustomRowCellEditForEditing(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            cboSanPham.Properties.NullText = gridView2.GetRowCellValue(e.RowHandle, "TenSP").ToString().Trim();
            txtSoLuong.Text = gridView2.GetRowCellValue(e.RowHandle, "SLNhap").ToString().Trim();
            txtDonGiaNhap.Text = gridView2.GetRowCellValue(e.RowHandle, "DonGiaNhap").ToString().Trim();

        }

        


    }
}
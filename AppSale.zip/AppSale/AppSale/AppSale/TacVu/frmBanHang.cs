﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;
using DevExpress.XtraGrid.Views.Grid;
namespace AppSale.TacVu
{
    public partial class frmBanHang : DevExpress.XtraEditors.XtraForm
    {
        public frmBanHang()
        {
            InitializeComponent();
        }
        getData dt = new getData();
        methods mt = new methods();
        Methods.method ham = new Methods.method();
        private void frmBanHang_Load(object sender, EventArgs e)
        {
            LoadHoaDonBan();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #region LoadData
        private void LoadHoaDonBan()
        {
            gridControl1.DataSource = dt.getHoaDonBan();
        }
       
        #endregion

        #region Events
        private void btnThem_Click(object sender, EventArgs e)
        {
            ham.ClearText(this);
        }
        //private void btnExit_Click(object sender, EventArgs e)
        //{
        //    this.Close();
        //}
        //private void btnThem_Click(object sender, EventArgs e)
        //{
        //    Add();
        //}
        //private void btnXoa_Click(object sender, EventArgs e)
        //{
        //    Delete();
        //}
        //private void btnSua_Click(object sender, EventArgs e)
        //{
        //    Edit();
        //}

        //private void gridControl1_FocusedViewChanged(object sender, DevExpress.XtraGrid.ViewFocusEventArgs e)
        //{
           
        //}
        //private void gridView1_Click(object sender, EventArgs e)
        //{
        //    txtMaHD.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "MaHD").ToString();
        //    txtMaNV.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "TenNV").ToString();
        //    txtMaKH.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "TenKH").ToString();
        //    txtNgayBan.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "NgayBan").ToString();
        //    txtTongTien.Text = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "TongTien").ToString();
        //}

        #endregion
        #region Methods
       
        //private void Save()
        //{
        //    if (txtMaHD.Text == string.Empty || txtMaNV.Text == string.Empty || txtMaKH.Text == string.Empty || txtNgayBan.Text == string.Empty || txtTongTien.Text == string.Empty)
        //    {
        //        MessageBox.Show("Mời nhập đầy đủ thông tin", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //    else
        //    {
        //        mt.AddHangBan(txtMaHD.Text, txtMaNV.Text, txtMaKH.Text.ToString(), txtNgayBan.Text,txtTongTien.Text);
        //        LoadHoaDonBan();
        //    }
        //}
      
        //private void Edit()
        //{
        //    //txtMaHD.Te
        //    if (txtNgayBan.Text == string.Empty || txtTongTien.Text == string.Empty)
        //    {
        //        MessageBox.Show("Mời nhập đầy đủ thông tin", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }

        //    else
        //    {
        //        mt.EditHoaDonBan(txtMaHD.Text, txtMaNV.Text, txtMaKH.Text, txtNgayBan.Text,txtTongTien.Text);
        //        LoadHoaDonBan();
        //    }
        //    LoadHoaDonBan();
        //}
        //private void Delete()
        //{
        //    if (MessageBox.Show("Bạn có chắc muốn xóa hóa đơn này", "Thông Báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != System.Windows.Forms.DialogResult.Cancel)
        //    {
        //        string id = gridView1.GetRowCellValue(gridView1.FocusedRowHandle, "MaHD").ToString();
        //        mt.DeleteHoaDon(id);
        //    }

        //    LoadHoaDonBan();
        //}
        #endregion

    
        

  
      

     

      
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;

namespace AppSale.TacVu
{
    public partial class frmHangHoa : DevExpress.XtraEditors.XtraForm
    {
        getData data = new getData();
        methods mt = new methods();
        public frmHangHoa()
        {
            InitializeComponent();
        }
        #region Load dữ liệu
        private void frmHangHoa_Load(object sender, EventArgs e)
        {
            loadDGVSanPham();
            loadCboDonViTinh();
            loadCboNhaCungCao();
        }

        private void loadCboNhaCungCao()
        {
            cboNhaCungCap.Properties.DataSource = data.getNhaCungCap();
            cboNhaCungCap.Properties.DisplayMember = "TenNCC";
            cboNhaCungCap.Properties.ValueMember = "MaNCC";
        }
        public void loadCboDonViTinh()
        {
            cboDonViTinh.Properties.DataSource = data.getDonViTinh();
            cboDonViTinh.Properties.DisplayMember = "TenDV";
        }

        private void loadDGVSanPham()
        {
            dgvSanPham.DataSource = data.getSanPham();
            
        }
        #endregion


        #region Events
        private void btnTaiAnh_Click(object sender, EventArgs e)
        {            
            OpenFileDialog open = new OpenFileDialog();
            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureEdit1.Image = Image.FromFile(open.FileName);
               // this.Text = open.FileName;
                
            }


        }

        private void gridView1_CustomRowCellEditForEditing(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            txtMaSanPham.Text = gridView1.GetRowCellValue(e.RowHandle, "MaSP").ToString().Trim();
            txtTenSanPham.Text = gridView1.GetRowCellValue(e.RowHandle, "TenSP").ToString().Trim();
            cboDonViTinh.Properties.NullText = gridView1.GetRowCellValue(e.RowHandle, "DonViTinh").ToString().Trim();
            txtSoLuongTon.Text = gridView1.GetRowCellValue(e.RowHandle, "SLTon").ToString().Trim();
            txtGiaBan.Text = gridView1.GetRowCellValue(e.RowHandle, "GiaBan").ToString().Trim();
            txtGiaNhap.Text = gridView1.GetRowCellValue(e.RowHandle, "GiaNhap").ToString().Trim();
            cboNhaCungCap.Properties.NullText = gridView1.GetRowCellValue(e.RowHandle, "TenNCC").ToString().Trim();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string maSP = txtMaSanPham.Text.ToString();
            string tenSP = txtTenSanPham.Text.ToString();
            string donViTinh = cboDonViTinh.Text.ToString();
            string slTon = txtSoLuongTon.Text.ToString();
            string giaNhap = txtGiaNhap.Text.ToString();
            string giaBan = txtGiaBan.Text.ToString();
            string maNCC = cboNhaCungCap.EditValue.ToString();
            mt.themSanPham(maSP, tenSP, donViTinh, slTon, giaBan, giaNhap, maNCC);
            loadDGVSanPham();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string maSP = txtMaSanPham.Text.ToString();
            mt.xoaSanPham(maSP);
            loadDGVSanPham();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            //string maSP = txtMaSanPham.Text.ToString();
            //string tenSP = txtTenSanPham.Text.ToString();
            //string donViTinh = cboDonViTinh.Text.ToString();
            //string slTon = txtSoLuongTon.Text.ToString();
            //string giaNhap = txtGiaNhap.Text.ToString();
            //string giaBan = txtGiaBan.Text.ToString();
            //string maNCC = cboNhaCungCap.EditValue.ToString();
            //mt.suaSanPham(maSP, tenSP, donViTinh, slTon, giaBan, giaNhap, maNCC);
            //dgvSanPham.DataSource = null;
            //loadDGVSanPham();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnLuu_Click(object sender, EventArgs e)
        {
            Luu();
        }

        #endregion

        #region Methods
        private void Luu()
        {
            
        }

        #endregion

        private void pictureEdit1_MouseClick(object sender, MouseEventArgs e)
        {
          
        }

    }
}
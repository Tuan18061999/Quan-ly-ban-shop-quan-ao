﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;

namespace AppSale.TacVu
{
    public partial class frmKhachHang : DevExpress.XtraEditors.XtraForm
    {
        getData data = new getData();
        methods mt = new methods();
        public frmKhachHang()
        {
            InitializeComponent();
        }

        private void frmKhachHang_Load(object sender, EventArgs e)
        {
            loadDGVKhachHang();
        }

        private void loadDGVKhachHang()
        {
            dgvKhachHang.DataSource = data.getKhachHang();
        }
    }
}
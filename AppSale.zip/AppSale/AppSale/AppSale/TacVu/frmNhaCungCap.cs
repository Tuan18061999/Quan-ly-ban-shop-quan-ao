﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using BLL_DLL;

namespace AppSale.TacVu
{
    public partial class frmNhaCungCap : DevExpress.XtraEditors.XtraForm
    {
        getData data = new getData();
        methods mt = new methods();
        public frmNhaCungCap()
        {
            InitializeComponent();
        }

        private void frmNhaCungCap_Load(object sender, EventArgs e)
        {
            loadDGVNhaCungCap();
        }
        private void loadDGVNhaCungCap()
        {
            dgvNhaCungCap.DataSource = data.getNhaCungCap();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string maNCC = txtMaNCC.Text.ToString();
            string tenNCC = txtTenNCC.Text.ToString();
            string sdtNCC = txtSDT.Text.ToString();
            string diaChiNCC = txtDiaChi.Text.ToString();
            mt.ThemNCC(maNCC, tenNCC, sdtNCC, diaChiNCC);
            loadDGVNhaCungCap();
        }

        private void btnXoaTrang_Click(object sender, EventArgs e)
        {

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string maNCC = txtMaNCC.Text.ToString();
            string tenNCC = txtTenNCC.Text.ToString();
            string sdtNCC = txtSDT.Text.ToString();
            string diaChiNCC = txtDiaChi.Text.ToString();
            mt.SuaNCC(maNCC, tenNCC, sdtNCC, diaChiNCC);
            loadDGVNhaCungCap();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string maNCC = txtMaNCC.Text.ToString();
            mt.XoaNCC(maNCC);
            loadDGVNhaCungCap();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {

        }

        private void gridView1_CustomRowCellEditForEditing(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            txtMaNCC.Text = gridView1.GetRowCellValue(e.RowHandle, "MaNCC").ToString().Trim();
            txtTenNCC.Text = gridView1.GetRowCellValue(e.RowHandle, "TenNCC").ToString().Trim();
            txtDiaChi.Text = gridView1.GetRowCellValue(e.RowHandle, "DiaChiNCC").ToString().Trim();
            txtSDT.Text = gridView1.GetRowCellValue(e.RowHandle, "SDTNCC").ToString().Trim();

            
        }
    }
}
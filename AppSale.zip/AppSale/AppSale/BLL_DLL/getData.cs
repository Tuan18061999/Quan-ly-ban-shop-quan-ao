﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_DLL
{
    public class getData
    {
        DBSaleDataContext db = new DBSaleDataContext();

        public getData()
        {

        }

        public IQueryable getNhanVien()
        {
            var nhanviens = from nv in db.NhanViens
                            select nv;
            return nhanviens;
        }

        public IQueryable getHoaDonBan()
        {
            var hoadonbans = from hd in db.HoaDonBans
                             join kh in db.KhachHangs on hd.MaKH equals kh.MaKH
                             join nv in db.NhanViens on hd.MaNV equals nv.MaNV
                             select new { hd.MaHD,nv.TenNV,kh.TenKH,hd.NgayBan,hd.TongTien };
            return hoadonbans;
        }
        //----------------------------------------------------------------------------------
        //NHA CUNG CAP
        public IQueryable getNhaCungCap()
        {
            var nhacungcaps = from ncc in db.NhaCungCaps
                              select ncc;
            return nhacungcaps;
        }
        //------------------------------------------------------------------------------------
        //SAN PHAM
        public IQueryable getSanPham()
        {
            var sanphams = from sp in db.SanPhams
                           join ncc in db.NhaCungCaps
                           on sp.MaNCC equals ncc.MaNCC
                           where sp.MaNCC == ncc.MaNCC
                           select new
                           {
                               sp.MaSP,
                               sp.TenSP,
                               sp.DonViTinh,
                               sp.SLTon,
                               sp.GiaBan,
                               sp.GiaNhap,
                               ncc.TenNCC
                           };
            return sanphams;
        }
        //------------------------------------------------------------------------------------
        //DON VI TINH
        public IQueryable getDonViTinh()
        {
            var donvitinhs = from dvt in db.DonViTinhs select dvt;
            return donvitinhs;
        }
        //------------------------------------------------------------------------------------
        //KHACH HANG
        public IQueryable getKhachHang()
        {
            var khachhangs = from kh in db.KhachHangs
                             join nkh in db.NhomKhachHangs
                             on kh.MaNhom equals nkh.MaNhom
                             select new
                             {
                                 kh.MaKH,
                                 kh.TenKH,
                                 kh.DiaChi,
                                 kh.GioiTinh,
                                 kh.SDT,
                                 kh.DiemTichLuy,
                                 nkh.TenNhom
                             };
            return khachhangs;
        }
        //------------------------------------------------------------------------------------------------
        //PHIEU NHAP
        public IQueryable getPhieuNhap()
        {
            var phieunhaps = from pn in db.PhieuNhaps
                             join nv in db.NhanViens
                             on pn.MaNV equals nv.MaNV
                             join ncc in db.NhaCungCaps
                             on pn.MaNCC equals ncc.MaNCC
                             select new
                             {
                                 pn.MaPN,
                                 pn.NgayNhap,
                                 nv.TenNV,
                                 ncc.TenNCC,
                                 pn.TongTienNhap
                             };
            return phieunhaps;
        }
        //------------------------------------------------------------------------------------------------
        //CHI TIET PHIEU NHAP
        public IQueryable getChiTietPhieuNhapTheoMa(string maPN)
        {
            var chitietphieunhaps = from ctpn in db.ChiTietPhieuNhaps
                                    join sp in db.SanPhams
                                    on ctpn.MaSP equals sp.MaSP
                                    where ctpn.MaPN.Equals(maPN)
                                    select new
                                    {
                                        sp.TenSP,
                                        ctpn.SLNhap,
                                        sp.GiaNhap,
                                        ctpn.ThanhTien
                                    };
            return chitietphieunhaps;
        }
        

    }
}

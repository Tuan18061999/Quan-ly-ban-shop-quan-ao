﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraGrid;
namespace BLL_DLL
{
    public class methods
    {
        public methods()
        {

        }
        DBSaleDataContext db = new DBSaleDataContext();
        NhaCungCap ncc = new NhaCungCap();
        SanPham sp = new SanPham();
        public void DeleteNV(string id)
        {
            var nv = db.NhanViens.Where(a => a.MaNV == id).SingleOrDefault();
            db.NhanViens.DeleteOnSubmit(nv);
            db.SubmitChanges();
        }

        public void AddNV(string MaNV,string TenNV,string sdt,string DiaChi)
        {
            NhanVien nv = new NhanVien();

            if (db.NhanViens.Any(a => a.MaNV == MaNV) == false)
            {
                nv.MaNV = MaNV;
                nv.TenNV = TenNV;
                nv.SDT = int.Parse(sdt);
                nv.DiaChi = DiaChi;
                db.NhanViens.InsertOnSubmit(nv);
                db.SubmitChanges();
            }
            else
                MessageBox.Show("Nhân Viên Đã Tồn Tại","Thông Báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        public void EditNV(string MaNV,string TenNV,string sdt,string DiaChi)
        {
            NhanVien nv = db.NhanViens.Single(p => p.MaNV == MaNV);
            nv.TenNV = TenNV;
            nv.SDT = int.Parse(sdt);
            nv.DiaChi = DiaChi;

            try
            {
                db.SubmitChanges();
            }
            catch (Exception)
            {
                
                throw;
            }


        }


        public void AddHangBan(string MaHD, string MaNV, string MaKH, string NgayBan,string TongTien)
        {
            HoaDonBan bh = new HoaDonBan();

            if (db.HoaDonBans.Any(a => a.MaHD == MaHD) == false)
            {
                bh.MaHD = MaHD;
                bh.MaNV = MaNV;
                bh.MaKH = MaKH;
                bh.NgayBan = DateTime.Parse(NgayBan);
                bh.TongTien = int.Parse(TongTien);
                db.HoaDonBans.InsertOnSubmit(bh);
                db.SubmitChanges();
            }
            else
                MessageBox.Show("Hóa Đơn Đã Tồn Tại Đã Tồn Tại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void DeleteHoaDon(string id)
        {
            var hd = db.HoaDonBans.Where(a => a.MaHD == id).SingleOrDefault();
            db.HoaDonBans.DeleteOnSubmit(hd);
            db.SubmitChanges();
        }
        public void EditHoaDonBan(string MaHD, string MaNV, string MaKH, string NgayBan, string TongTien)
        {
            HoaDonBan hd = db.HoaDonBans.Single(p => p.MaHD == MaHD);
            hd.NgayBan = DateTime.Parse(NgayBan);
            hd.TongTien = int.Parse(TongTien);

            try
            {
                db.SubmitChanges();
            }
            catch (Exception)
            {

                throw;
            }


        }
//------------------------------------------------------------------------------------------------------
        //Them xoa sua NHA CUNG CAP
        public void ThemNCC(string maNCC, string tenNCC, string SDTNCC, string diaChiNCC)
        {

            if (db.NhaCungCaps.Any(a => a.MaNCC == maNCC) == false)
            {
                ncc.MaNCC = maNCC;
                ncc.TenNCC = tenNCC;
                ncc.SDTNCC = SDTNCC;
                ncc.DiaChiNCC = diaChiNCC;
                db.NhaCungCaps.InsertOnSubmit(ncc);
                db.SubmitChanges();
            }
            else
                MessageBox.Show("Nhà cung cấp đã Tồn Tại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void XoaNCC(string maNCC)
        {
            var nhacungcaps = db.NhaCungCaps.Where(t => t.MaNCC == maNCC).FirstOrDefault();
            db.NhaCungCaps.DeleteOnSubmit(nhacungcaps);
            db.SubmitChanges();
        }
        public void SuaNCC(string maNCC, string tenNCC, string SDTNCC, string diaChiNCC)
        {
            NhaCungCap nhacungcaps = db.NhaCungCaps.Where(t => t.MaNCC == maNCC).FirstOrDefault();
            nhacungcaps.TenNCC = tenNCC;
            nhacungcaps.SDTNCC = SDTNCC;
            nhacungcaps.DiaChiNCC = diaChiNCC;
            try
            {
                db.SubmitChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
//-------------------------------------------------------------------------------------------------------
        //Them xoa sua SAN PHAM
        public void themSanPham(string maSP, string tenSP, string donViTinh, string slTon, string giaBan, string giaNhap, string maNCC)
        {
            if (db.SanPhams.Any(t=>t.MaSP==maSP)==false)
            {
                sp.MaSP = maSP;
                sp.TenSP = tenSP;
                sp.DonViTinh = donViTinh;
                sp.SLTon = int.Parse(slTon);
                sp.GiaBan = int.Parse(giaBan);
                sp.GiaNhap = int.Parse(giaNhap);
                sp.MaNCC = maNCC;
            }
            db.SanPhams.InsertOnSubmit(sp);
            db.SubmitChanges();
        }

        public void xoaSanPham(string maSP)
        {
            SanPham sanphams = db.SanPhams.Where(t => t.MaSP.Equals(maSP)).FirstOrDefault();
            db.SanPhams.DeleteOnSubmit(sanphams);
            db.SubmitChanges();
        }
        public void suaSanPham(string maSP, string tenSP, string donViTinh, string slTon, string giaBan, string giaNhap, string maNCC)
        {
            SanPham sanphams = db.SanPhams.Where(t => t.MaSP.Equals(maSP)).FirstOrDefault();
            sanphams.MaSP = maSP;
            sanphams.TenSP = tenSP;
            sanphams.DonViTinh = donViTinh;
            sanphams.SLTon = int.Parse(slTon);
            sanphams.GiaBan = int.Parse(giaBan);
            sanphams.GiaNhap = int.Parse(giaNhap);
            sanphams.MaNCC = maNCC;
            try
            {
                db.SubmitChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        #region DANG NHAP VA PHAN QUYEN
        public bool checkUserAndPassword(string userName, string passWord)
        {
            QL_NguoiDung qlnd = db.QL_NguoiDungs.Where(t => t.TenDangNhap.Equals(userName) & t.MatKhau.Equals(passWord)).FirstOrDefault();
            if (qlnd != null)
                return true;
            return false;
        }
        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace HopDen
{
    public class btnThem : Button
    {
        public btnThem()
        {
            Click += ButtonClear_Click;
        }
        Form frmm = new Form();
        void ButtonClear_Click(object sender, EventArgs e)
        {
            RecursiveClearTextBoxes(this.Controls);
        }
        private void RecursiveClearTextBoxes(Control.ControlCollection cc)
        {

            foreach (Control ctrl in cc)
            {

                TextBox tb = ctrl as TextBox;

                if (tb != null)

                    tb.Clear();

                else

                    RecursiveClearTextBoxes(ctrl.Controls);

            }

        }
    }
}
